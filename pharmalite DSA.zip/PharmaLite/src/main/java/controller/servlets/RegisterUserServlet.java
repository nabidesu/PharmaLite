package controller.servlets;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import controller.database.DBController;
import model.UserModel;
import Utils.StringUtils;
import Utils.ValidationUtils;

@WebServlet(asyncSupported = true, urlPatterns = { StringUtils.SERVLET_URL_REGISTER })
public class RegisterUserServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;
	private final DBController dbController;

	public RegisterUserServlet() {
		this.dbController = new DBController();
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		// Extract student information from request parameters
		String firstName = request.getParameter(StringUtils.FIRST_NAME);
		String lastName = request.getParameter(StringUtils.LAST_NAME);

		String address = request.getParameter(StringUtils.ADDRESS);

		String contact = request.getParameter(StringUtils.CONTACT);

		String username = request.getParameter(StringUtils.USER_NAME);
		String password = request.getParameter(StringUtils.PASSWORD);
		String email = request.getParameter(StringUtils.EMAIL);

		// Create a StudentModel object to hold student information
		UserModel user = new UserModel(firstName, lastName, address, contact, username, password, email);

		//Validation for user details
		if (!ValidationUtils.isTextOnly(firstName) || !ValidationUtils.isTextOnly(lastName)
				|| !ValidationUtils.isAlphanumeric(username) || !ValidationUtils.isEmail(email)
				|| !ValidationUtils.isNumbersOnly(contact) || !ValidationUtils.isAlphanumeric(address)) {
			request.setAttribute(StringUtils.MESSAGE_ERROR, StringUtils.MESSAGE_ERROR_INCORRECT_DATA);
			request.getRequestDispatcher(StringUtils.PAGE_URL_REGISTER).forward(request, response);
		}
		// Check if the username already exists in the database
		if (dbController.checkUsernameIfExists(username)) {
			request.setAttribute(StringUtils.MESSAGE_ERROR, StringUtils.MESSAGE_ERROR_USERNAME);
			request.getRequestDispatcher(StringUtils.PAGE_URL_REGISTER).forward(request, response);
			return;
		}
		// Check if the email already exists in the database
		if (dbController.checkEmailIfExists(email)) {
			request.setAttribute(StringUtils.MESSAGE_ERROR, StringUtils.MESSAGE_ERROR_EMAIL);
			request.getRequestDispatcher(StringUtils.PAGE_URL_REGISTER).forward(request, response);
			return;
		}
		 // Check if the contact number already exists in the database
		if (dbController.checkNumberIfExists(contact)) {
			request.setAttribute(StringUtils.MESSAGE_ERROR, StringUtils.MESSAGE_ERROR_CONTACT);
			request.getRequestDispatcher(StringUtils.PAGE_URL_REGISTER).forward(request, response);
			return;
		}
		// Call DBController to register the student
		int result = dbController.registerUser(user);

		if (result == 1) {  //Successful

			request.setAttribute(StringUtils.MESSAGE_SUCCESS, StringUtils.MESSAGE_SUCCESS_REGISTER);
			response.sendRedirect(request.getContextPath() + StringUtils.PAGE_URL_LOGIN + "?success=true");
		} else if (result == 0) { //Failed
			request.setAttribute(StringUtils.MESSAGE_ERROR, StringUtils.MESSAGE_ERROR_REGISTER);
			request.getRequestDispatcher(StringUtils.PAGE_URL_REGISTER).forward(request, response);
		} else { //Server error 
			request.setAttribute(StringUtils.MESSAGE_ERROR, StringUtils.MESSAGE_ERROR_SERVER);
			request.getRequestDispatcher(StringUtils.PAGE_URL_REGISTER).forward(request, response);
		}
	}
}
