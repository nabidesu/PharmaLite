package model;

import java.io.File;
import java.sql.Date;
import java.time.LocalDate;

import javax.servlet.http.Part;

import com.mysql.cj.util.StringUtils;

public class ProductModel {
	private String id;
	private String name;
	private String price;
	private LocalDate expiryDate;

	public ProductModel() {
	}

	public ProductModel(String id, String name, String price, LocalDate expiryDate) {
		super();
		this.id = id;
		this.name = name;
		this.price = price;
		this.expiryDate = expiryDate;

	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPrice() {
		return price;
	}

	public void setPrice(String price) {
		this.price = price;
	}

	public LocalDate getExpirydate() {
		return expiryDate;
	}

	public void setExpirydate(LocalDate localDate) {
		this.expiryDate = localDate;
	}

	// TODO Auto-generated method stub

}
