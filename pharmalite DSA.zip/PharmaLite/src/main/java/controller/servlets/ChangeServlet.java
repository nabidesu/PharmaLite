package controller.servlets;

import java.io.IOException;
import java.time.LocalDate;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import controller.database.DBController;
import model.ProductModel;
import Utils.StringUtils;
import Utils.ValidationUtils;

/**
 * Servlet implementation class ModifyServlet
 */
@WebServlet(asyncSupported = true, urlPatterns = "/ChangeServlet")
public class ChangeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private final DBController dbController;

	public ChangeServlet() {
		this.dbController = new DBController();
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		//Retrieves parameters from the request
		String updateId = request.getParameter(StringUtils.UPDATE_ID);
		String deleteId = request.getParameter(StringUtils.DELETE_ID);
		// If the updateId parameter is present, invoke the doUpdate method
		if (updateId != null && !updateId.isEmpty()) {
			doUpdate(request, response);
			
		}
		// If the deleteId parameter is present, invoke the doDelete method
		if (deleteId != null && !deleteId.isEmpty()) {
			doDelete(request, response);
			
		}

	}
	 /**
     * Handles HTTP PUT requests sent to the servlet.
     */

	@Override
	protected void doPut(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		System.out.println("put triggered");
	}
	/**
     * Handles HTTP DELETE requests sent to the servlet.
     */
	@Override
	protected void doDelete(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// Retrieve the deleteId parameter from the request
		String deleteId = req.getParameter(StringUtils.DELETE_ID);
		System.out.println("Product ID to delete: " + deleteId);
		if (dbController.deleteProductInfo(req.getParameter(StringUtils.DELETE_ID)) == 1) {
			System.out.println("Product deleted successfully");
			req.setAttribute(StringUtils.MESSAGE_SUCCESS, StringUtils.MESSAGE_SUCCESS_DELETE);
			resp.sendRedirect(req.getContextPath() + StringUtils.URL_PHARMACIST);
		} else {
			System.out.println("Failed to delete product");
			req.setAttribute(StringUtils.MESSAGE_ERROR, StringUtils.MESSAGE_ERROR_DELETE);
			resp.sendRedirect(req.getContextPath() + StringUtils.URL_PHARMACIST);
		}
	}
	/**
     * Handles product update requests.
     */
	protected void doUpdate(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String productId = request.getParameter("productID");
		String productName = request.getParameter("productName");
		String productPrice = request.getParameter("productPrice");
		LocalDate expiryDate = LocalDate.parse(request.getParameter("expiryDate"));

		// Create a ProductModel object with the retrieved parameters

		ProductModel product = new ProductModel(productId, productName, productPrice, expiryDate);
		product.setId(productId);
		product.setName(productName);
		product.setPrice(productPrice);
		product.setExpirydate(expiryDate);
		// Update the product information in the database
		int result = dbController.updateProductInfo(product);

		if (result == 1) {

			request.setAttribute(StringUtils.MESSAGE_SUCCESS, StringUtils.MESSAGE_SUCCESS);
			response.sendRedirect(request.getContextPath() + StringUtils.URL_PHARMACIST + "?success=true");
		} else if (result == 0) {
			request.setAttribute(StringUtils.MESSAGE_ERROR, StringUtils.MESSAGE_ERROR);
			request.getRequestDispatcher(StringUtils.URL_PHARMACIST).forward(request, response);
		} else if (result == -1) {
			request.setAttribute(StringUtils.MESSAGE_ERROR, StringUtils.MESSAGE_ERROR_SERVER);
			request.getRequestDispatcher(StringUtils.URL_PHARMACIST).forward(request, response);
		} else if (result == -2) {
			request.setAttribute(StringUtils.MESSAGE_ERROR, StringUtils.MESSAGE_ERROR_INCORRECT_DATA);
			request.getRequestDispatcher(StringUtils.URL_PHARMACIST).forward(request, response);
		}
	}

}
