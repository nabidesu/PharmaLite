package controller.database;

import java.sql.Connection;

import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;

import Utils.StringUtils;
import Utils.ValidationUtils;
import model.LoginModel;
import model.PasswordEncryptionWithAes;
import model.ProductModel;
import model.UserModel;
/**
 * This class handles database operations for user registration, login, product management, and related tasks.
 */

public class DBController {
	
	public Connection getConnection() throws SQLException, ClassNotFoundException {
		Class.forName(StringUtils.DRIVER_NAME);

		// Create a connection to the database using the provided credentials
		return DriverManager.getConnection(StringUtils.LOCALHOST_URL, StringUtils.LOCALHOST_USERNAME,
				StringUtils.LOCALHOST_PASSWORD);
	}
	/**
	 * Registers a new user in the database.
	 * 
	 * @param user UserModel object containing user information
	 * @return 1 if registration is successful, 0 if registration fails, -1 if an internal error occurs
	 */
	public int registerUser(UserModel user) {

		try {
			// Prepare a statement using the predefined query for student registration
			PreparedStatement stmt = getConnection().prepareStatement(StringUtils.QUERY_REGISTER_USER);

			// Set the student information in the prepared statement
			stmt.setString(1, user.getFirstName());
			stmt.setString(2, user.getLastName());
			stmt.setString(3, user.getAddress());
			stmt.setString(4, user.getContact());
			stmt.setString(5, user.getUsername());
			stmt.setString(6, PasswordEncryptionWithAes.encrypt(user.getUsername(), user.getPassword()));
			stmt.setString(7, user.getEmail());

			// Execute the update statement and store the number of affected rows
			int result = stmt.executeUpdate();

			// Check if the update was successful (i.e., at least one row affected)
			if (result > 0) {
				return 1; // Registration successful
			} else {
				return 0; // Registration failed (no rows affected)
			}

		} catch (ClassNotFoundException | SQLException ex) {
			// Print the stack trace for debugging purposes
			ex.printStackTrace();
			return -1; // Internal error
		}
	}
	/**
	 * Validates user login credentials against the database.
	 * 
	 * @param loginModel LoginModel object containing login credentials
	 * @return 1 if login is successful, 0 if username or password is incorrect, -1 if username is not found,
	 *         -2 if an internal error occurs
	 */
	public int getUserLoginInfo(LoginModel loginModel) {
		// TODO Auto-generated method stub
		try {
			// Prepare a statement using the predefined query for login check
			PreparedStatement st = getConnection().prepareStatement(StringUtils.QUERY_LOGIN_USER_CHECK);

			// Set the username in the first parameter of the prepared statement
			st.setString(1, loginModel.getUsername());

			// Execute the query and store the result set
			ResultSet result = st.executeQuery();

			// Check if there's a record returned from the query
			if (result.next()) {
				// Get the username from the database
				String userDb = result.getString(StringUtils.USER_NAME);

				// Get the password from the database
				String encryptedPwd = result.getString(StringUtils.PASSWORD);
				String decryptedPwd = PasswordEncryptionWithAes.decrypt(encryptedPwd, userDb);
				// String decryptedPwd = PasswordEncryptionWithAes.decr
				// Check if the username and password match the credentials from the database
				if (userDb.equals(loginModel.getUsername()) && decryptedPwd.equals(loginModel.getPassword())) {
					// Login successful, return 1
					return 1;
				} else {
					// Username or password mismatch, return 0
					return 0;
				}
			} else {
				// Username not found in the database, return -1
				return -1;
			}

			// Catch SQLException and ClassNotFoundException if they occur
		} catch (SQLException | ClassNotFoundException ex) {
			// Print the stack trace for debugging purposes
			ex.printStackTrace();
			// Return -2 to indicate an internal error
			return -2;
		}
	}
	/**
	 * Validates if a pharmacist exists in the database based on the provided username.
	 * 
	 * @param loginModel LoginModel object containing the username of the pharmacist
	 * @return 1 if pharmacist exists, 0 if pharmacist doesn't exist, -1 if an internal error occurs
	 */
	public int getPharmacistInfo(LoginModel loginModel) {
		try {
			// Prepare a statement using the predefined query for pharmacist info check
			PreparedStatement st = getConnection().prepareStatement(StringUtils.QUERY_CHECK_PHARMACIST);
			st.setString(1, loginModel.getUsername());

			// Execute the query and store the result set
			ResultSet result = st.executeQuery();

			// Check if there's a record returned from the query
			if (result.next()) {
				// Pharmacist record found in the database
				return 1;
			} else {
				// Pharmacist record not found in the database
				return 0;
			}
		} catch (SQLException | ClassNotFoundException ex) {
			// Print the stack trace for debugging purposes
			ex.printStackTrace();
			// Return -1 to indicate an internal error
			return -1;
		}
	}
	//To check if user email  already exist
	public Boolean checkEmailIfExists(String email) {
		try (Connection con = getConnection()) {
			PreparedStatement st = con.prepareStatement(StringUtils.QUERY_CHECK_EMAIL_EXISTS);
			st.setString(1, email);
			ResultSet rs = st.executeQuery();
			return rs.next();
		} catch (SQLException | ClassNotFoundException ex) {
			ex.printStackTrace();
			return null; // Handle exception appropriately
		}
	}
	//To check if user number already exist
	public Boolean checkNumberIfExists(String number) {
		try (Connection con = getConnection()) {
			PreparedStatement st = con.prepareStatement(StringUtils.QUERY_CHECK_NUMBER_EXISTS);
			st.setString(1, number);
			ResultSet rs = st.executeQuery();
			return rs.next();
		} catch (SQLException | ClassNotFoundException ex) {
			ex.printStackTrace();
			return null; // Handle exception appropriately
		}
	}
	//To check if Username already exist
	public Boolean checkUsernameIfExists(String username) {
		try (Connection con = getConnection()) {
			PreparedStatement st = con.prepareStatement(StringUtils.QUERY_CHECK_USERNAME_EXISTS);
			st.setString(1, username);
			ResultSet rs = st.executeQuery();
			return rs.next();
		} catch (SQLException | ClassNotFoundException ex) {
			ex.printStackTrace();
			return null; // Handle exception appropriately
		}
	}
	//To check if Product Name already exist
	public Boolean checkProductNameIfExists(String name) {
		try (Connection con = getConnection()) {
			PreparedStatement st = con.prepareStatement(StringUtils.QUERY_CHECK_PRODUCT_EXISTS);
			st.setString(1, name);
			ResultSet rs = st.executeQuery();
			return rs.next();
		} catch (SQLException | ClassNotFoundException ex) {
			ex.printStackTrace();
			return null; // Handle exception appropriately
		}
	}
	//To check if Product ID already exist
	public Boolean checkProductIDIfExists(String id ) {
		try (Connection con = getConnection()) {
			PreparedStatement st = con.prepareStatement(StringUtils.QUERY_CHECK_PRODUCT_IDEXISTS);
			st.setString(1, id);
			ResultSet rs = st.executeQuery();
			return rs.next();
		} catch (SQLException | ClassNotFoundException ex) {
			ex.printStackTrace();
			return null; // Handle exception appropriately
		}
	}
	
//ArrayList of UserModel objects containing information of all users
	public ArrayList<UserModel> getAllUsersInfo() {
		try (Connection con = getConnection()) {
			PreparedStatement st = con.prepareStatement(StringUtils.QUERY_GET_ALL_USER);
			ResultSet rs = st.executeQuery();

			ArrayList<UserModel> users = new ArrayList<>();

			while (rs.next()) {
				UserModel user = new UserModel();
				user.setFirstName(rs.getString("First_Name"));
				user.setLastName(rs.getString("Last_Name"));
				user.setAddress(rs.getString("Patient_Address"));
				user.setContact(rs.getString("Patient_Contact"));
				user.setEmail(rs.getString("Patient_Email"));
				user.setUsername(rs.getString("Patient_Username"));
				users.add(user);
			}
			return users;
		} catch (SQLException | ClassNotFoundException ex) {
			ex.printStackTrace();
			return null;
		}
	}
//Inserts product details into the database
	public int insertProductDetails(ProductModel product) {
		try {
			 
			// Prepare a statement using the predefined query 
			PreparedStatement stmt = getConnection().prepareStatement(StringUtils.QUERY_ADD_PRODUCTS);
			stmt.setString(1, product.getId());
			stmt.setString(2, product.getName());
			stmt.setString(3, product.getPrice());
			stmt.setDate(4, Date.valueOf(product.getExpirydate()));

			int result = stmt.executeUpdate();
			if (result > 0) {
				// Insertion successful
				return 1;
			} else {
				// Insertion failed
				return 0;
			}

		} catch (SQLException | ClassNotFoundException ex) {
			// Handle exception
			ex.printStackTrace();
			return -1; // Internal error
		}
	}
	//ArrayList of ProductModel objects containing information of all product
	public ArrayList<ProductModel> getAllProducts() {
		try (Connection con = getConnection()) {
			PreparedStatement stmt = con.prepareStatement(StringUtils.QUERY_GET_ALL_PRODUCTS);
			ResultSet rs = stmt.executeQuery();

			ArrayList<ProductModel> products = new ArrayList<>();

			while (rs.next()) {
				ProductModel product = new ProductModel();
				// Set product details from the result set
				product.setId(rs.getString("Product_ID"));
				product.setName(rs.getString("Product_Name"));
				product.setPrice(rs.getString("Product_Price"));
				product.setExpirydate(rs.getDate("Expiry_Date").toLocalDate());
				
				products.add(product);
			}

			return products;
		} catch (SQLException | ClassNotFoundException ex) {
			ex.printStackTrace();
			return null;
		}

	}
	/**
	 * Deletes product information from the database based on the provided product ID.
	 * 
	 * @param id String representing the product ID to delete
	 * @return 1 if deletion is successful, 0 if deletion fails, -1 if an internal error occurs
	 */
	public int deleteProductInfo(String id) {
		try (Connection con = getConnection()) {
			System.out.println("Deleting product with ID: " + id);
			PreparedStatement st = con.prepareStatement(StringUtils.QUERY_DELETE_PRODUCT);
			st.setString(1, id);
			int result = st.executeUpdate();

			
			return result;

		} catch (SQLException | ClassNotFoundException ex) {
			ex.printStackTrace(); // Log the exception for debugging
			return -1;
		}
	}
	/**
	 * Updates product information in the database based on the provided ProductModel object.
	 * 
	 * @param product ProductModel object containing updated product information
	 * @return 1 if update is successful, 0 if update fails, -1 if an internal error occurs
	 */
	public int updateProductInfo(ProductModel product) {
		try (Connection con = getConnection()) {
			
			// Prepare the SQL statement to update plan information
			PreparedStatement stmt = con.prepareStatement(StringUtils.QUERY_UPDATE_PRODUCT);

			// Set the parameters for the SQL statement
			// stmt.setString(1, product.getId());
			stmt.setString(1, product.getName());
			stmt.setString(2, product.getPrice());
			stmt.setDate(3, Date.valueOf(product.getExpirydate()));
			stmt.setString(4, product.getId());
			System.out.println("projectID " + product.getId());
			System.out.println("projectName " + product.getName());
			System.out.println("projectprice " + product.getPrice());
			System.out.println("Expirydate" + product.getExpirydate());

			// Execute the update operation
			int result = stmt.executeUpdate();

			// Check if the update was successful (i.e., at least one row affected)
			if (result > 0) {
				return 1; // Update successful
			} else {
				return 0; // Update failed (no rows affected)
			}
		} catch (ClassNotFoundException | SQLException ex) {
			// Print the stack trace for debugging purposes
			ex.printStackTrace();
			return -1; // Internal error
		}
	}

	
	
}
