package controller.servlets;

import java.io.IOException;
import java.sql.Date;
import java.time.LocalDate;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import Utils.StringUtils;
import Utils.ValidationUtils;
import controller.database.DBController;
import model.ProductModel;
import model.UserModel;
import java.sql.Date;

@WebServlet(urlPatterns = "/ModifyServlet", asyncSupported = true)

public class ModifyServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private final DBController dbController;

	public ModifyServlet() {
		this.dbController = new DBController();
	}
	/**
     * Handles HTTP GET requests.
     * Fetches all products from the database and forwards the request to PharmacistHome.jsp.
     */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		DBController dbController = new DBController();
		ArrayList<ProductModel> products = dbController.getAllProducts();
		request.setAttribute("products", products);
		request.getRequestDispatcher("/PharmacistHome.jsp").forward(request, response);

	}
	 /**
     * Handles HTTP POST requests.
     * Inserts a new product into the database based on the submitted form data.
     */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String productId = request.getParameter("Product_ID");
		String productName = request.getParameter("Product_Name");
		String productPrice = request.getParameter("Product_Price");
		LocalDate expiryDate = LocalDate.parse(request.getParameter("Expiry_Date"));
	
		ProductModel product = new ProductModel(productId, productName, productPrice, expiryDate);
		// Validate product name and price
		if (!ValidationUtils.isTextOnly(productName) || !ValidationUtils.isNumbersOnly(productPrice))  {
        	request.setAttribute(StringUtils.MESSAGE_ERROR, StringUtils.MESSAGE_ERROR_INCORRECT_DATA);
			request.getRequestDispatcher(StringUtils.URL_PHARMACIST).forward(request, response);
			return;
        }
		 // Check if the product name already exists in the database
		if (dbController.checkProductNameIfExists(productName)) {
			request.setAttribute(StringUtils.MESSAGE_ERROR, StringUtils.MESSAGE_ERROR);
			request.getRequestDispatcher(StringUtils.URL_PHARMACIST).forward(request, response);
			return;
		}
		 // Check if the product ID already exists in the database
		if (dbController.checkProductIDIfExists(productId)) {
			request.setAttribute(StringUtils.MESSAGE_ERROR, StringUtils.MESSAGE_ERROR);
			request.getRequestDispatcher(StringUtils.URL_PHARMACIST).forward(request, response);
			return;
		}
		int result = dbController.insertProductDetails(product);
		if (result == 1) {

			request.setAttribute(StringUtils.MESSAGE_SUCCESS, StringUtils.MESSAGE_SUCCESS);
			response.sendRedirect(request.getContextPath() + StringUtils.URL_PHARMACIST + "?success=true");
		} else if (result == 0) {
			request.setAttribute(StringUtils.MESSAGE_ERROR, StringUtils.MESSAGE_ERROR);
			request.getRequestDispatcher(StringUtils.URL_PHARMACIST).forward(request, response);
		} else {
			request.setAttribute(StringUtils.MESSAGE_ERROR, StringUtils.MESSAGE_ERROR_SERVER);
			request.getRequestDispatcher(StringUtils.PAGE_URL_REGISTER).forward(request, response);
		}
	}

}
