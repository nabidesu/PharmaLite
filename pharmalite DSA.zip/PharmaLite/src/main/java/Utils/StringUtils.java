package Utils;

import java.io.File;

public class StringUtils {

	// Start: DB Connection
	public static final String DRIVER_NAME = "com.mysql.cj.jdbc.Driver";
	public static final String LOCALHOST_URL = "jdbc:mysql://localhost:3306/pharmalite";
	public static final String LOCALHOST_USERNAME = "root";
	public static final String LOCALHOST_PASSWORD = "";

	public static final String IMAGE_ROOT_PATH = "C:\\Users\\Nitro\\eclipse-workspace\\PharmaLite\\src\\main\\webapp\\resources\\images";
	public static final String IMAGE_DIR_PRODUCT = "C:\\Users\\Nitro\\eclipse-workspace\\PharmaLite\\src\\main\\webapp\\resources\\images\\Products";
	public static final String IMAGE_DIR_USER = "C:/" + IMAGE_ROOT_PATH + "user\\";
	// End: DB Connection

	// Start: Queries

	public static final String QUERY_REGISTER_USER = "INSERT INTO patient_details ("
			+ "First_Name, Last_Name, Patient_Address,Patient_Contact,Patient_Username,password,Patient_Email) "
			+ "VALUES (?, ?, ?, ?, ?, ?, ?)";

	public static final String QUERY_LOGIN_USER_CHECK = "SELECT * FROM patient_details WHERE Patient_Username = ?";
	public static final String QUERY_GET_ALL_USER = "SELECT * FROM patient_details";
	public static final String QUERY_ADD_PRODUCTS = "INSERT INTO product_details (Product_ID,Product_Name,Product_Price,Expiry_Date,Pharmacist_ID) VALUES (?,?, ?,?,'Ad02')";
	public static final String QUERY_GET_ALL_PRODUCTS = "SELECT * FROM product_details";
	public static final String QUERY_GET_PRODUCT_ID = "SELECT Product_ID FROM product_details WHERE Product_Name = ?";
	public static final String QUERY_DELETE_PRODUCT = "DELETE FROM product_details  WHERE Product_ID = ?";
	public static final String QUERY_UPDATE_PRODUCT = "UPDATE product_details SET Product_Name = ?, Product_Price = ? ,Expiry_Date = ? WHERE Product_ID=?";
	public static final String QUERY_CHECK_PHARMACIST = "SELECT * FROM pharmacist_details WHERE username = ?";
	public static final String QUERY_CHECK_EMAIL_EXISTS = "SELECT * FROM patient_details WHERE Patient_Email = ?";
	public static final String QUERY_CHECK_NUMBER_EXISTS = "SELECT * FROM patient_details WHERE Patient_Contact = ?";
	public static final String QUERY_CHECK_USERNAME_EXISTS = "SELECT * FROM patient_details WHERE Patient_Username = ?";
	public static final String QUERY_DELETE_USER = "DELETE FROM student_info WHERE Patient_Username = ?";
	public static final String QUERY_CHECK_PRODUCT_EXISTS = "SELECT * FROM product_details WHERE Product_Name = ?";
	public static final String QUERY_CHECK_PRODUCT_IDEXISTS = "SELECT * FROM product_details WHERE Product_ID = ?";

	// End: Queries

	// Start: Parameter names
	public static final String USERNAME = "username";
	public static final String USER_NAME = "Patient_Username";
	public static final String FIRST_NAME = "First_Name";
	public static final String LAST_NAME = "Last_Name";
	public static final String ADDRESS = "Patient_Address";

	public static final String EMAIL = "Patient_Email";
	public static final String CONTACT = "Patient_Contact";

	public static final String PASSWORD = "password";
	public static final String RETYPE_PASSWORD = "retypePassword";
	public static final String PRODUCT_ID = "Product_ID";
	public static final String PRODUCT_NAME = "Product_Name";
	public static final String PRODUCT_PRICE = "Product_Price";
	public static final String EXPIRY_DATE = "Expiry_Date";
	public static final String PRODUCT_IMAGE = "Product_Image";
	// End: Parameter names

	// Start: Validation Messages
	// Register Page Messages
	public static final String MESSAGE_SUCCESS_REGISTER = "Successfully Registered!";
	public static final String MESSAGE_ERROR_REGISTER = "Please correct the form data.";
	public static final String MESSAGE_ERROR_USERNAME = "Username is already registered.";
	public static final String MESSAGE_ERROR_EMAIL = "Email is already registered.";
	public static final String MESSAGE_ERROR_CONTACT = "Phone number is already registered.";
	public static final String MESSAGE_ERROR_PASSWORD_UNMATCHED = "Password is not matched.";
	public static final String MESSAGE_ERROR_INCORRECT_DATA = "Please correct all the fields.";

	// Login Page Messages
	public static final String MESSAGE_SUCCESS_LOGIN = "Successfully LoggedIn!";
	public static final String MESSAGE_ERROR_LOGIN = "Either username or password is not correct!";
	public static final String MESSAGE_ERROR_CREATE_ACCOUNT = "Account for this username is not registered! Please create a new account.";

	// Other Messages
	public static final String MESSAGE_ERROR_SERVER = "An unexpected server error occurred.";
	public static final String MESSAGE_SUCCESS_DELETE = "Successfully Deleted!";
	public static final String MESSAGE_ERROR_DELETE = "Cannot delete the user!";

	public static final String MESSAGE_SUCCESS = "successMessage";
	public static final String MESSAGE_ERROR = "errorMessage";
	// End: Validation Messages

	// Start: JSP Route
	public static final String PAGE_URL_LOGIN = "/pages/login.jsp";
	public static final String PAGE_URL_REGISTER = "/pages/register.jsp";
	public static final String PAGE_URL_HOME = "/pages/Home.jsp";
	public static final String PAGE_URL_FOOTER = "pages/footer.jsp";
	public static final String PAGE_URL_HEADER = "pages/header.jsp";
	public static final String URL_LOGIN = "/login.jsp";
	public static final String URL_INDEX = "/index.jsp";
	public static final String URL_PHARMACIST = "/PharmacistHome.jsp";
	// End: JSP Route

	// Start: Servlet Route
	public static final String SERVLET_URL_LOGIN = "/login";
	public static final String SERVLET_URL_REGISTER = "/registeruser";
	public static final String SERVLET_URL_LOGOUT = "/logout";
	public static final String SERVLET_URL_HOME = "/home";
	public static final String SERVLET_URL_MODIFY = "/ModifyServlet";
	public static final String SERVLET_URL_CHANGE = "/changeservlet";
	public static final String SERVLET_URL_USER = "/UserProfileServlet";

	// End: Servlet Route

	// Start: Normal Text
	public static final String USER = "user";
	public static final String SUCCESS = "success";
	public static final String TRUE = "true";
	public static final String JSESSIONID = "JSESSIONID";
	public static final String LOGIN = "Login";
	public static final String LOGOUT = "Logout";
	public static final String USER_MODEL = "userModel";
	public static final String USER_LISTS = "userLists";
	public static final String SLASH = "/";
	public static final String DELETE_ID = "deleteId";
	public static final String UPDATE_ID = "updateId";
	// End: Normal Text
}