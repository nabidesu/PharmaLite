package controller.servlets;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import Utils.StringUtils;

import controller.database.DBController;
import model.LoginModel;

@WebServlet(urlPatterns = StringUtils.SERVLET_URL_LOGIN, asyncSupported = true)
public class LoginServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;
	private final DBController dbController;

	public LoginServlet() {
		this.dbController = new DBController();
	}

	/**
	 * Handles HTTP POST requests for login.
	 *
	 * @param request  The HttpServletRequest object containing login form data.
	 * @param response The HttpServletResponse object for sending responses.
	 * @throws ServletException if a servlet-specific error occurs.
	 * @throws IOException      if an I/O error occurs.
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		// Extract username and password from the request parameters
		String userName = request.getParameter(StringUtils.USERNAME);
		String password = request.getParameter(StringUtils.PASSWORD);

		LoginModel loginModel = new LoginModel(userName, password);

		// Call DBController to validate login credentials

		int pharmacistloginResult = dbController.getPharmacistInfo(loginModel);
		if (pharmacistloginResult == 1) {
			// If pharmacist exists, redirect to pharmacist.jsp
			response.sendRedirect(request.getContextPath() + "/PharmacistHome.jsp");
			 // Create and set session attributes for pharmacist
			HttpSession pharmacistSession = request.getSession();
			pharmacistSession.setAttribute(StringUtils.USERNAME, userName);
			pharmacistSession.setMaxInactiveInterval(30 * 60);
			// Create and set user cookie for pharmacist
			Cookie userCookie = new Cookie(StringUtils.USER, userName);
			userCookie.setMaxAge(30 * 60);
			response.addCookie(userCookie);
			System.out.println("Pharmacist sessionID: " + pharmacistSession.getId());

			return; // Exit the method to prevent further processing
		}
		int loginResult = dbController.getUserLoginInfo(loginModel);
		if (loginResult == 1) {
			// Create and set session attributes for patient
			HttpSession userSession = request.getSession();
			userSession.setAttribute(StringUtils.USERNAME, userName);
			userSession.setMaxInactiveInterval(30 * 60);
			// Create and set user cookie for patient
			Cookie userCookie = new Cookie(StringUtils.USER, userName);
			userCookie.setMaxAge(30 * 60);
			response.addCookie(userCookie);
			System.out.println("Patient sessionID: " + userSession.getId());

			request.setAttribute(StringUtils.MESSAGE_SUCCESS, StringUtils.MESSAGE_SUCCESS_LOGIN);
			response.sendRedirect(request.getContextPath() + StringUtils.PAGE_URL_HOME);
		} else if (loginResult == 0) {
			// Username or password mismatch
			request.setAttribute(StringUtils.MESSAGE_ERROR, StringUtils.MESSAGE_ERROR_LOGIN);
			request.setAttribute(StringUtils.USERNAME, userName);
			request.getRequestDispatcher(StringUtils.PAGE_URL_LOGIN).forward(request, response);
		} else if (loginResult == -1) {
			// Username not found
			request.setAttribute(StringUtils.MESSAGE_ERROR, StringUtils.MESSAGE_ERROR_CREATE_ACCOUNT);
			request.setAttribute(StringUtils.USERNAME, userName);
			request.getRequestDispatcher(StringUtils.PAGE_URL_LOGIN).forward(request, response);
		} else {
			// Internal server error
			request.setAttribute(StringUtils.MESSAGE_ERROR, StringUtils.MESSAGE_ERROR_SERVER);
			request.setAttribute(StringUtils.USERNAME, userName);
			request.getRequestDispatcher(StringUtils.PAGE_URL_LOGIN).forward(request, response);
		}
	}

}